__version__ = "1.5.2"

from .pandarallel import pandarallel
