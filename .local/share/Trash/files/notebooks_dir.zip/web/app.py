from flask import Flask,render_template,request, url_for,send_from_directory
import predictor
import pandas as pd 

app = Flask(__name__)

res = [
    ['Lewis Hamilton: Mercedes', '94%'],
    ['Max Verstappen: Red Bull', '89%'],
    ['Valtteri Bottas: Mercedes', '61%'],
    ['Sergio Pérez: Red Bull', '42%'],
    ['Charles Leclerc: Ferrari', '21%'],
]

@app.route("/images/<path:path>")
def static_dir(path):
    return send_from_directory("images", path)

@app.route('/')
def get_input():
    return render_template('index.html')

@app.route('/predict',methods=['POST'])
def predict_position():
    circuit = request.form['circuit']
    weather = request.form['weather']

    #res = predictor.pred(circuit, weather)
    #print (res)
    df = pd.DataFrame(res, columns = {'Driver','Prediction'} )
    return render_template('index.html',tables=[df.to_html(classes='driver')])

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080, debug=True)


