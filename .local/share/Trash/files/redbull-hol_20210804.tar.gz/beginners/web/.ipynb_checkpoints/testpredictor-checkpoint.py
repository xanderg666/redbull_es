import predictor
import pandas as pd

active_drivers = [['Daniel Ricciardo','McLaren'], 
                  ['Mick Schumacher','Haas F1 Team'], 
                  ['Carlos Sainz','Ferrari'],
                  ['Valtteri Bottas','Mercedes'], 
                  ['Lance Stroll','Aston Martin'], 
                  ['George Russell','Williams'],
                  ['Lando Norris','McLaren'], 
                  ['Sebastian Vettel','Aston Martin'], 
                  ['Kimi Räikkönen','Alfa Romeo'],
                  ['Charles Leclerc','Ferrari'], 
                  ['Lewis Hamilton','Mercedes'], 
                  ['Yuki Tsunoda','AlphaTauri'],
                  ['Max Verstappen','Red Bull'], 
                  ['Pierre Gasly','AlphaTauri'], 
                  ['Fernando Alonso','Alpine F1'],
                  ['Sergio Pérez','Red Bull'], 
                  ['Esteban Ocon','Alpine F1'], 
                  ['Antonio Giovinazzi','Alfa Romeo'],
                  ['Nikita Mazepin','Haas F1 Team'],
                  ['Nicholas Latifi','Williams']]

#active_drivers.head()
res = []
for row in active_drivers:
    #for elem in row:
    driver = row[0]
    constructor = row[1]
    quali = "1"
    circuit = "Hungaroring"
    my_prediction, driver_confidence, constructor_reliablity = predictor.pred(driver,constructor,quali,circuit)
    my_rangeprediction, driver_confidence, constructor_reliablity = predictor.pred(driver,constructor,quali,circuit)
    predpercentage = "{:.2%}".format(constructor_reliablity/driver_confidence)
    #print ("%s: %s : %s : %s : %s : %s " % (driver, constructor, my_rangeprediction, driver_confidence, constructor_reliablity, predpercentage))
    elem = [driver, constructor, my_rangeprediction, driver_confidence, constructor_reliablity, predpercentage]
    res.append(elem)

print(res)

# pandas analysis    

df = pd.DataFrame(res, columns = ['Driver','Constructor','podium', 'driver_confidence', 'constructor_reliablity', 'Prediction'])
# Filter only Drivers with Podium probability
df = df[df['podium']==1]
print(df)
df = df.sort_values(['constructor_reliablity','driver_confidence'], ascending=False).head(5)
#df = df.sort_values(['Prediction'], ascending=False).head(5)
#df=df.drop(['Constructor','podium','driver_confidence', 'constructor_reliablity'],1)
print(df)    
    
# prediction = predictor.pred('British Grand Prix',3,'Red Bull','Max Verstappen')
# print(prediction)


